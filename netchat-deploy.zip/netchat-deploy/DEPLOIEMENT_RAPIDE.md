# ⚡ Guide Rapide: Déployer NetChat en 5 Minutes

## 🎯 Les 5 Étapes (Pour Vraiment!)

### **Étape 1: Créer un compte GitHub** (2 min)
👉 https://github.com/signup
- Entre ton email
- Crée un mot de passe
- Confirme par email

### **Étape 2: Créer un repo GitHub** (1 min)
1. Une fois connecté, clique le **+** en haut à droite
2. Clique **"New repository"**
3. Nomme-le: `netchat`
4. Clique **"Create repository"**

### **Étape 3: Uploader le code** (1 min)

Sur la page de ton repo, tu verras un bouton **"Add file"**

Clique et sélectionne **"Upload files"**

**Télécharge ces fichiers du dossier outputs:**
- `multidevice_messenger.jsx` → Dans un dossier `src/` en ligne
- `package.json` → À la racine
- `public_index.html` → Renomme en `index.html` dans un dossier `public/`

**Ou plus simple:** Envoie les 3 fichiers, GitHub va les organiser

Clique **"Commit changes"** en bas

### **Étape 4: Créer un compte Vercel** (1 min)
👉 https://vercel.com

Clique **"Sign Up"** → Choisir **"GitHub"**

Autorise Vercel à accéder à GitHub

### **Étape 5: Déployer** (1 min)
1. Une fois connecté à Vercel, clique **"New Project"**
2. Clique **"Import Git Repository"**
3. Sélectionne `netchat` dans la liste
4. Clique **"Import"**
5. Les settings vont se remplir auto (laisse tout par défaut)
6. Clique **"Deploy"**

**BOOM! C'est déployé!** 🎉

Tu vas avoir une URL comme:
```
https://netchat-abc123.vercel.app
```

---

## ✅ Vérifier que ça marche

1. Ouvre l'URL dans ton navigateur
2. Crée 2 comptes différents (dans 2 onglets)
3. Ajoute-les en amis
4. Envoie un message et regarde la sync 💬

---

## 🎮 Tester sur Nintendo Switch

1. Ouvre le navigateur de ta Switch
2. Tape l'URL complète: `https://netchat-abc123.vercel.app`
3. C'est bon! 🎉

---

## 🚨 Si ça ne marche pas

### Erreur "Build failed"
- Vérifie que `package.json` est à la racine
- Vérifie que `src/App.jsx` (pas `.js`) existe
- Utilise les noms exacts de fichiers

### Page blanche
- Appuie sur F12 pour ouvrir la console
- Tu vas voir les erreurs
- Vérifie que les fichiers sont bien structurés

### Fichiers mal organisés?
```
netchat/
├── src/
│   ├── App.jsx (contenu de multidevice_messenger.jsx)
│   └── index.js (j'ai préparé)
├── public/
│   └── index.html (renomme de public_index.html)
└── package.json
```

---

## 💡 Conseil Pro

**Dès que tu vois une URL vercel.app**, c'est que c'est déployé!

Tu peux:
- Partager l'URL avec n'importe qui
- Y accéder depuis n'importe quel appareil
- Utiliser sur Switch en même temps sur PC

---

## 🎓 Prochains Pas (Optionnel)

Une fois que ça marche:

1. **Ajouter Firebase** pour une vraie base de données
2. **Domaine personnalisé** (netchat.fr)
3. **PWA** pour installer sur l'écran d'accueil

Mais pour maintenant, **c'est déjà complet!** 🚀

---

**Questions?** Envoie-moi un message! 💬