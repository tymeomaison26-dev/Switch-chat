# 💬 NetChat - Messagerie Multiappareils

Une application web de messagerie moderne avec système d'amis, synchronisation temps réel et fonctionnement sur **tous les appareils** (Switch, PC, téléphone).

## ✨ Caractéristiques

- ✅ **Multiappareils** - Utilisable sur Switch, PC, téléphone, tablette
- ✅ **Système d'amis** - Demandes d'ami avant messagerie
- ✅ **Sync temps réel** - Messages synchro automatiquement
- ✅ **Stockage persistant** - Les messages restent
- ✅ **Interface moderne** - Design épuré avec gradients
- ✅ **Gratuit** - 100% gratuit, pas de compte à créer

## 🚀 Déployer en 2 minutes

### Option 1: Vercel (RECOMMANDÉ)

```bash
# 1. Fork ou clone ce repo
git clone https://github.com/tonnom/netchat.git
cd netchat

# 2. Push sur GitHub
git push origin main

# 3. Va sur https://vercel.com
# 4. Clique "Import Project"
# 5. Sélectionne ton repo GitHub
# 6. Deploy!

# Résultat: https://netchat-xxx.vercel.app
```

### Option 2: Netlify

```bash
# 1. Va sur https://netlify.com
# 2. Connect GitHub
# 3. Sélectionne ton repo
# 4. Build command: npm run build
# 5. Publish: build
# 6. Deploy!

# Résultat: https://netchat.netlify.app
```

### Option 3: Localement

```bash
# 1. Node.js doit être installé
npm install
npm start

# 2. Ouvre http://localhost:3000
```

## 📱 Utilisation

1. **Créer un compte:** Tape ton pseudonyme et connecte-toi
2. **Ajouter des amis:** Va dans "Découvrir" → Cherche un utilisateur → Ajoute
3. **Accepter demandes:** Onglet "Demandes" → Accepte/Refuse
4. **Discuter:** Clique sur un ami et envoie des messages
5. **Multiappareils:** Ouvre sur une autre device et vois les messages arriver en temps réel!

## 🎮 Sur Nintendo Switch

1. Ouvre le navigateur
2. Tape l'URL: `https://tonsite.vercel.app`
3. C'est prêt! 💬

## 📁 Structure du Projet

```
netchat/
├── public/
│   └── index.html
├── src/
│   ├── App.jsx           (Composant principal)
│   └── index.js          (Entry point)
├── package.json          (Dépendances)
└── README.md
```

## 🔧 Configuration

### Environnement Local

```bash
# Installer les dépendances
npm install

# Démarrer le serveur dev
npm start

# Build pour production
npm build
```

## 🌐 Domaine Personnalisé

Une fois déployé sur Vercel:

1. Va dans Paramètres du projet
2. Clique "Domains"
3. Ajoute ton domaine (netchat.fr, etc.)
4. Suis les instructions DNS

## 🗄️ Stockage des Données

L'app utilise **window.storage** (Artifacts Storage de Claude) pour:
- Listes d'utilisateurs
- Listes d'amis et demandes
- Historique des messages

**Données persistes:** Oui, entre sessions
**Données partagées:** Oui, entre tous les appareils

## 🔐 Sécurité

⚠️ **Important:** 
- Pas de chiffrement (localhost only)
- Les données sont publiques (c'est une démo)
- Pour production: ajoute Firebase/Supabase + auth

## 🐛 Dépannage

### "Build error on Vercel"
```bash
# Vérifie que package.json existe
# Vérifie que le build fonctionne localement
npm run build
```

### "Blank page"
```bash
# Ouvre F12 (Console)
# Cherche les erreurs
# Vérifie que <div id="root"> existe dans public/index.html
```

### "Pas de sync entre appareils"
```bash
# Ouvre 2 onglets de ton site
# Connecte-toi avec 2 pseudos différents
# Envoie un message et regarde la sync
```

## 📚 Prochaines Étapes

1. **Base de données réelle** → Firebase ou Supabase
2. **Authentification** → Login/password sécurisé
3. **Notifications** → Push notifications
4. **Groupes** → Conversations de groupe
5. **Emojis/images** → Enrichir les messages

## 📞 Support

Besoin d'aide? 
- Vérifie la section **Dépannage** ci-dessus
- Regarde les logs (F12 → Console)
- Envoie un message sur les issues du repo

## 📄 Licence

MIT - Gratuit pour tous!

---

**Bon déploiement! 🚀**