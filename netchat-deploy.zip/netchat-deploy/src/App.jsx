import React, { useState, useEffect, useRef } from 'react';

export default function MultiDeviceMessenger() {
  const [currentUser, setCurrentUser] = useState(null);
  const [username, setUsername] = useState('');
  const [allUsers, setAllUsers] = useState([]);
  const [friends, setFriends] = useState([]);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [sentRequests, setSentRequests] = useState([]);
  const [selectedContact, setSelectedContact] = useState(null);
  const [messages, setMessages] = useState([]);
  const [messageText, setMessageText] = useState('');
  const [loading, setLoading] = useState(false);
  const [friendSearch, setFriendSearch] = useState('');
  const [activeTab, setActiveTab] = useState('friends');
  const messagesEndRef = useRef(null);
  const pollIntervalRef = useRef(null);

  // ======== FONCTIONS DE STOCKAGE ========

  const loadUsers = async () => {
    try {
      const result = await window.storage.get('users-list');
      if (result) return JSON.parse(result.value);
      return [];
    } catch {
      return [];
    }
  };

  const saveUsers = async (users) => {
    try {
      await window.storage.set('users-list', JSON.stringify(users));
    } catch (e) {
      console.error('Erreur sauvegarde utilisateurs:', e);
    }
  };

  const loadFriends = async (username) => {
    try {
      const result = await window.storage.get(`friends:${username}`);
      if (result) return JSON.parse(result.value);
      return [];
    } catch {
      return [];
    }
  };

  const saveFriends = async (username, friendsList) => {
    try {
      await window.storage.set(`friends:${username}`, JSON.stringify(friendsList));
    } catch (e) {
      console.error('Erreur sauvegarde amis:', e);
    }
  };

  const loadPendingRequests = async (username) => {
    try {
      const result = await window.storage.get(`pending-requests:${username}`);
      if (result) return JSON.parse(result.value);
      return [];
    } catch {
      return [];
    }
  };

  const savePendingRequests = async (username, requests) => {
    try {
      await window.storage.set(`pending-requests:${username}`, JSON.stringify(requests));
    } catch (e) {
      console.error('Erreur sauvegarde demandes:', e);
    }
  };

  const loadSentRequests = async (username) => {
    try {
      const result = await window.storage.get(`sent-requests:${username}`);
      if (result) return JSON.parse(result.value);
      return [];
    } catch {
      return [];
    }
  };

  const saveSentRequests = async (username, requests) => {
    try {
      await window.storage.set(`sent-requests:${username}`, JSON.stringify(requests));
    } catch (e) {
      console.error('Erreur sauvegarde demandes envoyées:', e);
    }
  };

  const loadMessages = async (user1, user2) => {
    try {
      const conversationKey = [user1, user2].sort().join('-');
      const result = await window.storage.get(`messages:${conversationKey}`);
      if (result) return JSON.parse(result.value);
      return [];
    } catch {
      return [];
    }
  };

  const saveMessages = async (user1, user2, messages) => {
    try {
      const conversationKey = [user1, user2].sort().join('-');
      await window.storage.set(`messages:${conversationKey}`, JSON.stringify(messages));
    } catch (e) {
      console.error('Erreur sauvegarde messages:', e);
    }
  };

  // ======== FONCTIONS DE GESTION DES AMIS ========

  const sendFriendRequest = async (targetUsername) => {
    if (!currentUser) return;

    let newSentRequests = [...sentRequests];
    if (!newSentRequests.includes(targetUsername)) {
      newSentRequests.push(targetUsername);
      setSentRequests(newSentRequests);
      await saveSentRequests(currentUser.name, newSentRequests);
    }

    try {
      let targetPendingRequests = await loadPendingRequests(targetUsername);
      if (!targetPendingRequests.includes(currentUser.name)) {
        targetPendingRequests.push(currentUser.name);
        await savePendingRequests(targetUsername, targetPendingRequests);
      }
    } catch (e) {
      console.error('Erreur envoi demande:', e);
    }

    setFriendSearch('');
  };

  const acceptFriendRequest = async (fromUsername) => {
    if (!currentUser) return;

    let newFriends = [...friends];
    if (!newFriends.includes(fromUsername)) {
      newFriends.push(fromUsername);
      setFriends(newFriends);
      await saveFriends(currentUser.name, newFriends);
    }

    try {
      let theirFriends = await loadFriends(fromUsername);
      if (!theirFriends.includes(currentUser.name)) {
        theirFriends.push(currentUser.name);
        await saveFriends(fromUsername, theirFriends);
      }
    } catch (e) {
      console.error('Erreur acceptation:', e);
    }

    let newPendingRequests = pendingRequests.filter(req => req !== fromUsername);
    setPendingRequests(newPendingRequests);
    await savePendingRequests(currentUser.name, newPendingRequests);

    try {
      let theirSentRequests = await loadSentRequests(fromUsername);
      theirSentRequests = theirSentRequests.filter(req => req !== currentUser.name);
      await saveSentRequests(fromUsername, theirSentRequests);
    } catch (e) {
      console.error('Erreur retrait demande envoyée:', e);
    }
  };

  const rejectFriendRequest = async (fromUsername) => {
    if (!currentUser) return;

    let newPendingRequests = pendingRequests.filter(req => req !== fromUsername);
    setPendingRequests(newPendingRequests);
    await savePendingRequests(currentUser.name, newPendingRequests);

    try {
      let theirSentRequests = await loadSentRequests(fromUsername);
      theirSentRequests = theirSentRequests.filter(req => req !== currentUser.name);
      await saveSentRequests(fromUsername, theirSentRequests);
    } catch (e) {
      console.error('Erreur retrait demande:', e);
    }
  };

  // ======== FONCTIONS DE MESSAGES ========

  const handleLogin = async () => {
    if (!username.trim()) return;

    setLoading(true);
    try {
      let users = await loadUsers();
      let userExists = users.find(u => u.name === username);

      if (!userExists) {
        userExists = {
          name: username,
          createdAt: new Date().toISOString(),
          color: `hsl(${Math.random() * 360}, 70%, 60%)`
        };
        users.push(userExists);
        await saveUsers(users);
      }

      const friendsList = await loadFriends(username);
      const pending = await loadPendingRequests(username);
      const sent = await loadSentRequests(username);

      setCurrentUser(userExists);
      setAllUsers(users.filter(u => u.name !== username));
      setFriends(friendsList);
      setPendingRequests(pending);
      setSentRequests(sent);
      setUsername('');
      setActiveTab('friends');
    } catch (e) {
      console.error('Erreur connexion:', e);
    }
    setLoading(false);
  };

  const handleSelectContact = async (contactName) => {
    const contact = allUsers.find(u => u.name === contactName);
    setSelectedContact(contact);
    const msgs = await loadMessages(currentUser.name, contactName);
    setMessages(msgs);
    setMessageText('');
  };

  const handleSendMessage = async () => {
    if (!messageText.trim() || !selectedContact) return;

    const newMessage = {
      id: Date.now(),
      from: currentUser.name,
      to: selectedContact.name,
      text: messageText,
      timestamp: new Date().toISOString(),
      read: false
    };

    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages);
    await saveMessages(currentUser.name, selectedContact.name, updatedMessages);
    setMessageText('');
  };

  const syncMessages = async () => {
    if (!selectedContact || !currentUser) return;

    try {
      const msgs = await loadMessages(currentUser.name, selectedContact.name);
      setMessages(msgs);
    } catch (e) {
      console.error('Erreur sync:', e);
    }
  };

  // ======== EFFECTS ========

  useEffect(() => {
    if (selectedContact && currentUser) {
      syncMessages();
      pollIntervalRef.current = setInterval(syncMessages, 1000);
    }

    return () => {
      if (pollIntervalRef.current) {
        clearInterval(pollIntervalRef.current);
      }
    };
  }, [selectedContact, currentUser]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // ======== RENDER ========

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
        <style>{`
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
          .login-container {
            background: rgba(15, 23, 42, 0.8);
            backdrop-filter: blur(16px);
            border: 1px solid rgba(148, 163, 184, 0.2);
            border-radius: 20px;
            padding: 40px;
            max-width: 400px;
            width: 100%;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5);
          }
          .login-title {
            text-align: center;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 12px;
            background: linear-gradient(135deg, #60a5fa 0%, #a78bfa 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
          }
          .login-subtitle {
            text-align: center;
            color: #94a3b8;
            font-size: 14px;
            margin-bottom: 32px;
          }
          .input-group {
            margin-bottom: 20px;
          }
          .login-input {
            width: 100%;
            padding: 12px 16px;
            background: rgba(30, 41, 59, 0.8);
            border: 1px solid rgba(148, 163, 184, 0.3);
            border-radius: 10px;
            color: #f1f5f9;
            font-size: 14px;
            outline: none;
            transition: all 0.3s ease;
          }
          .login-input:focus {
            border-color: #60a5fa;
            box-shadow: 0 0 0 3px rgba(96, 165, 250, 0.1);
          }
          .login-btn {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #60a5fa 0%, #a78bfa 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
          }
          .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(96, 165, 250, 0.3);
          }
        `}</style>

        <div className="login-container">
          <div className="login-title">💬 NetChat</div>
          <div className="login-subtitle">Messagerie sécurisée entre amis</div>

          <div className="input-group">
            <input
              type="text"
              className="login-input"
              placeholder="Votre pseudonyme"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
              autoFocus
            />
          </div>

          <button
            className="login-btn"
            onClick={handleLogin}
            disabled={loading}
          >
            {loading ? 'Connexion...' : 'Se connecter'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-slate-900 flex flex-col">
      <style>{`
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }

        .header {
          background: linear-gradient(135deg, #60a5fa 0%, #a78bfa 100%);
          padding: 16px;
          color: white;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .header-content {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .header-title {
          font-size: 20px;
          font-weight: 700;
        }

        .user-info {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 13px;
        }

        .logout-btn {
          background: rgba(255, 255, 255, 0.2);
          border: 1px solid rgba(255, 255, 255, 0.3);
          color: white;
          padding: 8px 16px;
          border-radius: 6px;
          cursor: pointer;
          font-size: 12px;
          margin-left: 16px;
          transition: all 0.2s ease;
        }

        .logout-btn:hover {
          background: rgba(255, 255, 255, 0.3);
        }

        .main-container {
          display: flex;
          gap: 1px;
          flex: 1;
          overflow: hidden;
          background: #0f172a;
        }

        .sidebar {
          width: 320px;
          background: #1e293b;
          border-right: 1px solid #334155;
          display: flex;
          flex-direction: column;
          overflow: hidden;
        }

        .tabs {
          display: flex;
          border-bottom: 1px solid #334155;
          background: rgba(0, 0, 0, 0.2);
        }

        .tab {
          flex: 1;
          padding: 12px;
          text-align: center;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          border-bottom: 2px solid transparent;
          transition: all 0.2s ease;
          color: #94a3b8;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .tab.active {
          color: #60a5fa;
          border-bottom-color: #60a5fa;
        }

        .tab:hover {
          background: rgba(60, 165, 250, 0.1);
        }

        .sidebar-content {
          flex: 1;
          overflow-y: auto;
          padding: 8px;
          display: flex;
          flex-direction: column;
        }

        .request-card, .friend-item, .user-item {
          padding: 12px;
          margin-bottom: 8px;
          background: rgba(30, 41, 59, 0.5);
          border-radius: 8px;
          border-left: 3px solid transparent;
        }

        .request-card {
          border-left-color: #f59e0b;
        }

        .friend-item {
          cursor: pointer;
          transition: all 0.2s ease;
          border-left-color: #60a5fa;
        }

        .friend-item:hover {
          background: rgba(30, 41, 59, 0.8);
        }

        .friend-item.active {
          background: linear-gradient(135deg, rgba(96, 165, 250, 0.2) 0%, rgba(167, 139, 250, 0.2) 100%);
          font-weight: 600;
        }

        .user-item {
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .user-item:hover {
          background: rgba(30, 41, 59, 0.8);
        }

        .item-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 8px;
          font-size: 13px;
        }

        .item-name {
          font-weight: 600;
          color: #f1f5f9;
        }

        .item-status {
          font-size: 11px;
          color: #64748b;
        }

        .request-actions {
          display: flex;
          gap: 8px;
          margin-top: 8px;
        }

        .action-btn {
          flex: 1;
          padding: 6px;
          border: none;
          border-radius: 6px;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .accept-btn {
          background: #10b981;
          color: white;
        }

        .accept-btn:hover {
          background: #059669;
        }

        .reject-btn {
          background: #ef4444;
          color: white;
        }

        .reject-btn:hover {
          background: #dc2626;
        }

        .add-btn {
          background: #60a5fa;
          color: white;
          padding: 6px 12px;
          border-radius: 6px;
          font-size: 11px;
          cursor: pointer;
          border: none;
          transition: all 0.2s ease;
          white-space: nowrap;
        }

        .add-btn:hover {
          background: #3b82f6;
        }

        .add-btn.sent {
          background: #64748b;
          cursor: not-allowed;
        }

        .search-input {
          width: 100%;
          padding: 8px 12px;
          background: #1e293b;
          border: 1px solid #475569;
          border-radius: 8px;
          color: #f1f5f9;
          font-size: 13px;
          margin-bottom: 12px;
          outline: none;
        }

        .search-input:focus {
          border-color: #60a5fa;
        }

        .empty-message {
          color: #64748b;
          text-align: center;
          padding: 20px;
          font-size: 12px;
        }

        .chat-container {
          flex: 1;
          display: flex;
          flex-direction: column;
          background: #0f172a;
        }

        .chat-header {
          padding: 16px;
          border-bottom: 1px solid #334155;
          background: rgba(30, 41, 59, 0.5);
        }

        .chat-header-title {
          font-size: 16px;
          font-weight: 600;
          color: #f1f5f9;
        }

        .messages-area {
          flex: 1;
          overflow-y: auto;
          padding: 16px;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .message {
          display: flex;
          gap: 8px;
          animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .message.sent {
          justify-content: flex-end;
        }

        .message.received {
          justify-content: flex-start;
        }

        .message-bubble {
          max-width: 65%;
          padding: 10px 14px;
          border-radius: 14px;
          font-size: 13px;
          line-height: 1.4;
          word-wrap: break-word;
        }

        .message.sent .message-bubble {
          background: linear-gradient(135deg, #60a5fa 0%, #a78bfa 100%);
          color: white;
          border-bottom-right-radius: 4px;
        }

        .message.received .message-bubble {
          background: #334155;
          color: #f1f5f9;
          border-bottom-left-radius: 4px;
          border: 1px solid #475569;
        }

        .message-time {
          font-size: 11px;
          color: #64748b;
          display: flex;
          align-items: flex-end;
          padding: 0 4px;
        }

        .empty-state {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          color: #64748b;
          text-align: center;
        }

        .empty-icon {
          font-size: 48px;
          margin-bottom: 12px;
          opacity: 0.5;
        }

        .input-area {
          padding: 16px;
          border-top: 1px solid #334155;
          display: flex;
          gap: 8px;
          background: rgba(30, 41, 59, 0.5);
        }

        .message-input {
          flex: 1;
          background: #1e293b;
          border: 1px solid #475569;
          border-radius: 10px;
          padding: 10px 14px;
          color: #f1f5f9;
          font-size: 13px;
          outline: none;
          transition: all 0.2s ease;
          font-family: inherit;
        }

        .message-input:focus {
          border-color: #60a5fa;
          box-shadow: 0 0 0 3px rgba(96, 165, 250, 0.1);
        }

        .send-btn {
          background: linear-gradient(135deg, #60a5fa 0%, #a78bfa 100%);
          border: none;
          color: white;
          padding: 10px 20px;
          border-radius: 10px;
          cursor: pointer;
          font-size: 13px;
          font-weight: 600;
          transition: all 0.2s ease;
        }

        .send-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 16px rgba(96, 165, 250, 0.3);
        }

        ::-webkit-scrollbar {
          width: 6px;
        }

        ::-webkit-scrollbar-track {
          background: transparent;
        }

        ::-webkit-scrollbar-thumb {
          background: rgba(148, 163, 184, 0.3);
          border-radius: 3px;
        }

        ::-webkit-scrollbar-thumb:hover {
          background: rgba(148, 163, 184, 0.5);
        }
      `}</style>

      <div className="header">
        <div className="header-content">
          <div className="header-title">💬 NetChat</div>
          <div className="user-info">
            👤 {currentUser.name}
            <button
              className="logout-btn"
              onClick={() => setCurrentUser(null)}
            >
              Déconnexion
            </button>
          </div>
        </div>
      </div>

      <div className="main-container">
        <div className="sidebar">
          <div className="tabs">
            <div
              className={`tab ${activeTab === 'friends' ? 'active' : ''}`}
              onClick={() => setActiveTab('friends')}
            >
              👥 Amis ({friends.length})
            </div>
            <div
              className={`tab ${activeTab === 'requests' ? 'active' : ''}`}
              onClick={() => setActiveTab('requests')}
            >
              ✉️ Demandes ({pendingRequests.length})
            </div>
            <div
              className={`tab ${activeTab === 'discover' ? 'active' : ''}`}
              onClick={() => setActiveTab('discover')}
            >
              🔍 Découvrir
            </div>
          </div>

          <div className="sidebar-content">
            {/* TAB AMIS */}
            {activeTab === 'friends' && (
              <>
                {friends.length === 0 ? (
                  <div className="empty-message">
                    Aucun ami pour le moment.<br/>
                    Allez dans "Découvrir" pour en ajouter!
                  </div>
                ) : (
                  friends.map((friendName) => {
                    const friendUser = allUsers.find(u => u.name === friendName);
                    return (
                      <div
                        key={friendName}
                        className={`friend-item ${selectedContact?.name === friendName ? 'active' : ''}`}
                        onClick={() => handleSelectContact(friendName)}
                      >
                        <div className="item-header">
                          <span className="item-name">{friendName}</span>
                        </div>
                        <div className="item-status">✅ En ligne</div>
                      </div>
                    );
                  })
                )}
              </>
            )}

            {/* TAB DEMANDES */}
            {activeTab === 'requests' && (
              <>
                {pendingRequests.length === 0 ? (
                  <div className="empty-message">
                    Aucune demande d'ami en attente
                  </div>
                ) : (
                  pendingRequests.map((requesterName) => (
                    <div key={requesterName} className="request-card">
                      <div className="item-name">{requesterName}</div>
                      <div className="item-status">veut être ami avec vous</div>
                      <div className="request-actions">
                        <button
                          className="action-btn accept-btn"
                          onClick={() => acceptFriendRequest(requesterName)}
                        >
                          ✓ Accepter
                        </button>
                        <button
                          className="action-btn reject-btn"
                          onClick={() => rejectFriendRequest(requesterName)}
                        >
                          ✕ Refuser
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </>
            )}

            {/* TAB DÉCOUVRIR */}
            {activeTab === 'discover' && (
              <>
                <input
                  type="text"
                  className="search-input"
                  placeholder="Chercher un utilisateur..."
                  value={friendSearch}
                  onChange={(e) => setFriendSearch(e.target.value)}
                />
                {friendSearch.length > 0 ? (
                  allUsers
                    .filter(user =>
                      user.name.toLowerCase().includes(friendSearch.toLowerCase()) &&
                      !friends.includes(user.name) &&
                      !pendingRequests.includes(user.name)
                    )
                    .map((user) => (
                      <div key={user.name} className="user-item">
                        <div className="item-header">
                          <span className="item-name">{user.name}</span>
                          <button
                            className={`add-btn ${sentRequests.includes(user.name) ? 'sent' : ''}`}
                            onClick={() => sendFriendRequest(user.name)}
                            disabled={sentRequests.includes(user.name)}
                          >
                            {sentRequests.includes(user.name) ? '⏳ En attente' : '+ Ajouter'}
                          </button>
                        </div>
                        <div className="item-status">✅ En ligne</div>
                      </div>
                    ))
                ) : (
                  <div className="empty-message">
                    Tape un pseudonyme pour chercher des amis
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        <div className="chat-container">
          {selectedContact ? (
            <>
              <div className="chat-header">
                <div className="chat-header-title">💬 {selectedContact.name}</div>
              </div>

              <div className="messages-area">
                {messages.length === 0 ? (
                  <div className="empty-state">
                    <div className="empty-icon">👋</div>
                    <div>Aucun message. Commencez une conversation!</div>
                  </div>
                ) : (
                  messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`message ${msg.from === currentUser.name ? 'sent' : 'received'}`}
                    >
                      {msg.from !== currentUser.name && (
                        <div className="message-time">
                          {new Date(msg.timestamp).toLocaleTimeString('fr-FR', {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </div>
                      )}
                      <div className="message-bubble">{msg.text}</div>
                      {msg.from === currentUser.name && (
                        <div className="message-time">
                          {new Date(msg.timestamp).toLocaleTimeString('fr-FR', {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </div>
                      )}
                    </div>
                  ))
                )}
                <div ref={messagesEndRef} />
              </div>

              <div className="input-area">
                <input
                  type="text"
                  className="message-input"
                  placeholder="Votre message..."
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                />
                <button className="send-btn" onClick={handleSendMessage}>
                  Envoyer
                </button>
              </div>
            </>
          ) : (
            <div className="empty-state">
              <div className="empty-icon">👋</div>
              <div>Sélectionnez un ami pour commencer à discuter</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}